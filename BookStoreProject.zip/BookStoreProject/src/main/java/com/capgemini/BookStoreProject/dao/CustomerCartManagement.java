package com.capgemini.BookStoreProject.dao;


import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;



public interface CustomerCartManagement {

	public void clearCart();
	
	public Map<Integer, Book> removeABookFromCart(int bookId);
	
	public Map<Integer, Book> addABookToCart(Book book);
	
	public Map<Integer,Book> addQuantityOfABook(int bookId);
	
	public Map<Integer,Book> decreaseQuantityOfABook(int bookId);
	
	public Book searchBook(int bookId);
}
