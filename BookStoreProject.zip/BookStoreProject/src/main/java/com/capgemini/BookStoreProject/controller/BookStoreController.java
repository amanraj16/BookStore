package com.capgemini.BookStoreProject.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;
import com.capgemini.BookStoreProject.service.ServiceImpl;

@RestController
public class BookStoreController {

	@Autowired
	ServiceImpl serviceImpl;
	
	
	@RequestMapping(value="/")
	public String home()
	{
		return "home";
	}
	@RequestMapping(value="/showAllUsers",method=RequestMethod.GET)
	public List<Users> showAllUsers()
	{
		return serviceImpl.listAllUsers();
	}
	
	@RequestMapping(value="/showAllCustomers",method=RequestMethod.GET)
	public List<RegisterCustomer> showAllCustomers()
	{
		return serviceImpl.listAllCutomers();
	}
	
	
	@RequestMapping(value="/createUser",method=RequestMethod.PUT)
	public Users createUser(@RequestBody Users user) throws UserAlreadyExistException
	{
		return serviceImpl.createUser(user);
	}
	
	@RequestMapping(value="/createCustomer",method=RequestMethod.PUT)
	public RegisterCustomer createCustomer(@RequestBody RegisterCustomer customer) throws CustomerAlreadyExistException
	{
		return serviceImpl.registerCustomer(customer);
	}
	
	@RequestMapping(value="/deleteUser/{id}",method=RequestMethod.DELETE)
	public Users deleteUser(@PathVariable int id) throws UserDoesNotExistException
	{
		return serviceImpl.deleteUser(id);
	}
	
	@RequestMapping(value="/editUser/{id}",method=RequestMethod.PUT)
	public Users createUser(@PathVariable int id,@RequestBody Users user) throws UserDoesNotExistException
	{
		return serviceImpl.editUser(id, user);
	}
	
	@RequestMapping(value="/clearCart",method=RequestMethod.GET)
	public String clearCart()
	{
		return serviceImpl.clearCart();
	}
	
	@RequestMapping(value="/addABookToCart",method=RequestMethod.PUT)
	public Map<Integer,Book> addABookToCart(@RequestBody Book book)
	{
		return serviceImpl.addABookToCart(book);
	}
	
	@RequestMapping(value="/removeABookFromCart/{id}",method=RequestMethod.DELETE)
	public Map<Integer,Book> removeABookFromCart(@PathVariable int id) throws BookDoesNotExistException
	{
		return serviceImpl.removeABookFromCart(id);
	}
	
	@RequestMapping(value="/addQuantityOfBook/{id}",method=RequestMethod.PUT)
	public Map<Integer,Book> addQuantityOfBook(@PathVariable int id) throws BookCannotBeAddedMoreAsItIsOutOfStockException
	{
		return serviceImpl.addQuantityOfBook(id);
	}
	
	@RequestMapping(value="/decreaseQuantityOfBook/{id}",method=RequestMethod.PUT)
	public Map<Integer,Book> decreaseQuantityOfBook(@PathVariable int id)
	{
		return serviceImpl.decreaseQuantityOfBook(id);
	}
	
}

