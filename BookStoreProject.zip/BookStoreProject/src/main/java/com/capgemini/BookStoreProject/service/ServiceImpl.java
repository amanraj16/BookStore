package com.capgemini.BookStoreProject.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.dao.BookDAO;
import com.capgemini.BookStoreProject.dao.CustomerCartManagement;
import com.capgemini.BookStoreProject.dao.CustomerCartManagementImpl;
import com.capgemini.BookStoreProject.dao.CustomerDAO;
import com.capgemini.BookStoreProject.dao.UserDAO;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;

@org.springframework.stereotype.Service
public class ServiceImpl implements Service {

	@Autowired
	UserDAO userDAO;
	
	@Autowired
	CustomerDAO customerDAO;
	
	@Autowired
	BookDAO bookDAO;
	
	CustomerCartManagement customerCartMgmt = new CustomerCartManagementImpl();
	@Override
	public Users createUser(Users user) throws UserAlreadyExistException {
	String email=user.getEmail();
	List<Users> userList=listAllUsers();
	for(Users list: userList)
	{
		if(!email.equals(list.getEmail())) {
			userDAO.save(user);
			return user;
		}
	}
	throw new UserAlreadyExistException("This user already exists");
	}
			

	@Override
	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException {
		RegisterCustomer customerSearch = customerDAO.findById(customer.getPhonenumber()).get();
		if(customerSearch==null)
		{
			customerDAO.save(customer);
			return customer;
		}
		else
			throw new CustomerAlreadyExistException("This customer already exist");
		
	}

	@Override
	public String clearCart() {
		customerCartMgmt.clearCart();
		return "Cart cleared successfully";
	}

	@Override
	public Map<Integer,Book> addABookToCart(Book book) {
		Book bookSearch = customerCartMgmt.searchBook(book.getBookId());
		if(bookSearch==null)
		{
			return customerCartMgmt.addABookToCart(book);
		}
		else
		{
			bookSearch.setQuantity(bookSearch.getQuantity()+1);
			return customerCartMgmt.addABookToCart(bookSearch);
		}
	}

	@Override
	public Map<Integer, Book> removeABookFromCart(int bookId) throws BookDoesNotExistException {
		Book bookSearch = customerCartMgmt.searchBook(bookId);
		if(bookSearch!=null)
		{
			return customerCartMgmt.removeABookFromCart(bookId);
		}
		else
			throw new BookDoesNotExistException("This book does not exist in your cart");
		
	}

	@Override
	public Map<Integer, Book> addQuantityOfBook(int bookId) throws BookCannotBeAddedMoreAsItIsOutOfStockException {
		Book bookSearch = bookDAO.findById(bookId).get();
		if((bookSearch.getQuantity()-1)>=0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()-1);
			return customerCartMgmt.addQuantityOfABook(bookId);
		}
		else
			throw new BookCannotBeAddedMoreAsItIsOutOfStockException("No more quantity of this Book can be added as it has become OUT OF STOCK");
	}

	@Override
	public Users deleteUser(int userId) throws UserDoesNotExistException {
		Users userSearch = userDAO.findById(userId).get();
		if(userSearch!=null)
		{
			userDAO.delete(userSearch);
			return userSearch;
		}
		else
			throw new UserDoesNotExistException("This User does not exist");
	}

	@Override
	public Users editUser(int userId,Users updatedUser) throws UserDoesNotExistException {
		Users userSearch = userDAO.findById(userId).get();
		if(userSearch!=null)
		{
			userDAO.delete(userSearch);
			userDAO.save(updatedUser);
			return updatedUser;
		}
		else
			throw new UserDoesNotExistException("This user does not exist");
	}

	@Override
	public Map<Integer, Book> decreaseQuantityOfBook(int bookId) {
		Book bookSearch = bookDAO.findById(bookId).get();
		Book customerBook = customerCartMgmt.searchBook(bookId);
		if((customerBook.getQuantity()-1)==0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()+1);
			return customerCartMgmt.removeABookFromCart(customerBook.getBookId());
		}
		else
			return customerCartMgmt.decreaseQuantityOfABook(customerBook.getBookId());
	}

	@Override
	public List<Users> listAllUsers() {
		
		return userDAO.findAll();
	}
	
	@Override
	public List<RegisterCustomer> listAllCutomers() {
		
		return customerDAO.findAll();
	}

}
